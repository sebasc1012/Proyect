export { default } from './ShoeIndex';
