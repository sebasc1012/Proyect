export { default } from './ShoeCard';
